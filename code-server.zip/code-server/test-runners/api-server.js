#!/usr/bin/env node

/**
 * Simple API server to handle file operations and test execution
 * This runs inside the code-server container
 */

const express = require('express');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const app = express();
app.use(express.json({ limit: '50mb' }));

// Environment variables
const PORT = process.env.API_PORT || 3001;
const API_KEY = process.env.API_KEY || 'your-api-key';
const WORKSPACE_DIR = process.env.WORKSPACE_DIR || '/workspace';

// Middleware to check API key
const authenticateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey || apiKey !== API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  next();
};

// Function to ensure a workspace directory exists
const ensureWorkspaceDir = (testId) => {
  const workspaceDir = path.join(WORKSPACE_DIR, testId);
  const projectDir = path.join(workspaceDir, 'project');
  const testsDir = path.join(workspaceDir, 'tests');
  
  if (!fs.existsSync(workspaceDir)) {
    fs.mkdirSync(workspaceDir, { recursive: true });
  }
  if (!fs.existsSync(projectDir)) {
    fs.mkdirSync(projectDir, { recursive: true });
  }
  if (!fs.existsSync(testsDir)) {
    fs.mkdirSync(testsDir, { recursive: true });
  }
  
  return { workspaceDir, projectDir, testsDir };
};

// Create default directories
const defaultProjectDir = path.join(WORKSPACE_DIR, 'project');
const defaultTestsDir = path.join(WORKSPACE_DIR, 'tests');

if (!fs.existsSync(defaultProjectDir)) {
  fs.mkdirSync(defaultProjectDir, { recursive: true });
}
if (!fs.existsSync(defaultTestsDir)) {
  fs.mkdirSync(defaultTestsDir, { recursive: true });
}

// API routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Create workspace for a test
app.post('/api/workspace/create', (req, res) => {
  try {
    const { testId } = req.body;
    
    if (!testId) {
      return res.status(400).json({ error: 'Test ID is required' });
    }
    
    const { workspaceDir } = ensureWorkspaceDir(testId);
    
    res.json({
      success: true,
      workspaceDir
    });
  } catch (error) {
    console.error('Error creating workspace:', error);
    res.status(500).json({ error: 'Failed to create workspace' });
  }
});

// Update files for a specific test workspace
app.post('/api/workspace/:testId/files', (req, res) => {
  try {
    const { testId } = req.params;
    const { files } = req.body;
    
    if (!files || typeof files !== 'object') {
      return res.status(400).json({ error: 'Invalid files object' });
    }
    
    const { workspaceDir, projectDir, testsDir } = ensureWorkspaceDir(testId);
    
    // Write each file
    for (const [filePath, content] of Object.entries(files)) {
      // Determine if this is a project file or a test file
      let fullPath;
      if (filePath.startsWith('tests/')) {
        fullPath = path.join(testsDir, filePath.replace('tests/', ''));
      } else {
        fullPath = path.join(projectDir, filePath);
      }
      
      // Create directory if it doesn't exist
      const dirPath = path.dirname(fullPath);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
      
      // Write file
      fs.writeFileSync(fullPath, content);
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error updating files:', error);
    res.status(500).json({ error: 'Failed to update files' });
  }
});

// Legacy endpoint for backward compatibility
app.put('/files', authenticateApiKey, (req, res) => {
  try {
    const { files } = req.body;
    
    if (!files || typeof files !== 'object') {
      return res.status(400).json({ error: 'Invalid files object' });
    }
    
    // Write each file
    for (const [filePath, content] of Object.entries(files)) {
      // Determine if this is a project file or a test file
      const baseDir = filePath.startsWith('tests/') ? WORKSPACE_DIR : defaultProjectDir;
      const fullPath = path.join(baseDir, filePath.replace('tests/', ''));
      
      // Create directory if it doesn't exist
      const dirPath = path.dirname(fullPath);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
      
      // Write file
      fs.writeFileSync(fullPath, content);
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error updating files:', error);
    res.status(500).json({ error: 'Failed to update files' });
  }
});

// Run tests for a specific test workspace
app.post('/api/workspace/:testId/run-tests', (req, res) => {
  try {
    const { testId } = req.params;
    const { language = 'javascript' } = req.body;
    
    const { workspaceDir } = ensureWorkspaceDir(testId);
    const runnerPath = path.join(WORKSPACE_DIR, 'test-runners', 'run_tests.js');
    
    // Execute the test runner with the workspace directory
    exec(`node ${runnerPath} --workspace=${workspaceDir} --language=${language}`, (error, stdout, stderr) => {
      // Read test results
      const resultsPath = path.join(workspaceDir, 'test-results.json');
      
      if (fs.existsSync(resultsPath)) {
        const results = JSON.parse(fs.readFileSync(resultsPath, 'utf8'));
        
        res.json({
          success: results.failed === 0,
          results,
          output: stdout,
          error: stderr
        });
      } else {
        res.status(500).json({
          success: false,
          error: 'Test results not found',
          output: stdout,
          stderr
        });
      }
    });
  } catch (error) {
    console.error('Error running tests:', error);
    res.status(500).json({ error: 'Failed to run tests' });
  }
});

// Legacy endpoint for backward compatibility
app.post('/run-tests', authenticateApiKey, (req, res) => {
  try {
    const runnerPath = path.join(WORKSPACE_DIR, 'test-runners', 'run_tests.js');
    
    exec(`node ${runnerPath}`, (error, stdout, stderr) => {
      // Read test results
      const resultsPath = path.join(WORKSPACE_DIR, 'test-results.json');
      
      if (fs.existsSync(resultsPath)) {
        const results = JSON.parse(fs.readFileSync(resultsPath, 'utf8'));
        
        res.json({
          success: results.failed === 0,
          results,
          output: stdout,
          error: stderr
        });
      } else {
        res.status(500).json({
          success: false,
          error: 'Test results not found',
          output: stdout,
          stderr
        });
      }
    });
  } catch (error) {
    console.error('Error running tests:', error);
    res.status(500).json({ error: 'Failed to run tests' });
  }
});

// Get file content for a specific test workspace
app.get('/api/workspace/:testId/files/:filePath(*)', (req, res) => {
  try {
    const { testId, filePath } = req.params;
    
    const { workspaceDir, projectDir, testsDir } = ensureWorkspaceDir(testId);
    
    // Determine if this is a project file or a test file
    let fullPath;
    if (filePath.startsWith('tests/')) {
      fullPath = path.join(testsDir, filePath.replace('tests/', ''));
    } else {
      fullPath = path.join(projectDir, filePath);
    }
    
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    const content = fs.readFileSync(fullPath, 'utf8');
    
    res.json({ content });
  } catch (error) {
    console.error('Error getting file:', error);
    res.status(500).json({ error: 'Failed to get file' });
  }
});

// Legacy endpoint for backward compatibility
app.get('/files/:filePath(*)', authenticateApiKey, (req, res) => {
  try {
    const { filePath } = req.params;
    
    // Determine if this is a project file or a test file
    const baseDir = filePath.startsWith('tests/') ? WORKSPACE_DIR : defaultProjectDir;
    const fullPath = path.join(baseDir, filePath.replace('tests/', ''));
    
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    const content = fs.readFileSync(fullPath, 'utf8');
    
    res.json({ content });
  } catch (error) {
    console.error('Error getting file:', error);
    res.status(500).json({ error: 'Failed to get file' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`API server running on port ${PORT}`);
});
