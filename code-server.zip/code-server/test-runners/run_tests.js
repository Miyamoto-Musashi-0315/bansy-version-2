#!/usr/bin/env node

/**
 * Universal test runner script that detects the language and runs the appropriate tests
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuration for different languages
const languageConfigs = {
  javascript: {
    fileExtensions: ['.js', '.jsx', '.ts', '.tsx'],
    testCommand: (testFile) => `npx mocha ${testFile}`,
    testFilePattern: /test|spec/i
  },
  python: {
    fileExtensions: ['.py'],
    testCommand: (testFile) => `python3 -m pytest ${testFile} -v`,
    testFilePattern: /test|pytest/i
  },
  java: {
    fileExtensions: ['.java'],
    testCommand: (testFile) => {
      // Compile and run JUnit tests
      const className = path.basename(testFile, '.java');
      return `javac -cp .:junit-platform-console-standalone.jar ${testFile} && java -jar junit-platform-console-standalone.jar -cp . --select-class ${className}`;
    },
    testFilePattern: /Test/
  }
};

// Parse command line arguments
const args = process.argv.slice(2);
let customWorkspaceDir = null;
let customLanguage = null;

// Parse command line arguments
args.forEach(arg => {
  if (arg.startsWith('--workspace=')) {
    customWorkspaceDir = arg.split('=')[1];
  } else if (arg.startsWith('--language=')) {
    customLanguage = arg.split('=')[1];
  }
});

// Get the test ID from environment variable or extract from workspace path
const testId = process.env.TEST_ID || (customWorkspaceDir ? path.basename(customWorkspaceDir) : 'unknown');

// Get the workspace directory
const workspaceDir = customWorkspaceDir || process.env.WORKSPACE_DIR || '/workspace';
const projectDir = path.join(workspaceDir, 'project');
const testsDir = path.join(workspaceDir, 'tests');

// Ensure directories exist
if (!fs.existsSync(projectDir)) {
  fs.mkdirSync(projectDir, { recursive: true });
}
if (!fs.existsSync(testsDir)) {
  fs.mkdirSync(testsDir, { recursive: true });
}

// Detect language based on files in the project directory
function detectLanguage() {
  // If language is specified via command line, use that
  if (customLanguage && languageConfigs[customLanguage]) {
    return customLanguage;
  }
  
  // Otherwise detect from files
  try {
    const files = fs.readdirSync(projectDir);
    
    for (const language in languageConfigs) {
      const config = languageConfigs[language];
      
      for (const file of files) {
        const ext = path.extname(file);
        if (config.fileExtensions.includes(ext)) {
          return language;
        }
      }
    }
  } catch (error) {
    console.warn(`Warning: Could not read project directory: ${error.message}`);
  }
  
  // Default to JavaScript if no language detected
  return 'javascript';
}

// Find test files for the detected language
function findTestFiles(language) {
  const config = languageConfigs[language];
  const testFiles = [];
  
  const files = fs.readdirSync(testsDir);
  
  for (const file of files) {
    const ext = path.extname(file);
    if (config.fileExtensions.includes(ext) && config.testFilePattern.test(file)) {
      testFiles.push(path.join(testsDir, file));
    }
  }
  
  return testFiles;
}

// Run tests for the specified language
function runTests(language, testFiles) {
  const config = languageConfigs[language];
  const results = {
    passed: 0,
    failed: 0,
    tests: []
  };
  
  console.log(`Running ${language} tests for test ID: ${testId}`);
  
  for (const testFile of testFiles) {
    const testName = path.basename(testFile);
    console.log(`\nRunning test: ${testName}`);
    
    try {
      const command = config.testCommand(testFile);
      const output = execSync(command, { encoding: 'utf8' });
      
      console.log(output);
      
      results.passed++;
      results.tests.push({
        name: testName,
        passed: true,
        output
      });
    } catch (error) {
      console.error(`Test failed: ${error.message}`);
      
      results.failed++;
      results.tests.push({
        name: testName,
        passed: false,
        output: error.stdout || error.message
      });
    }
  }
  
  return results;
}

// Main function
function main() {
  try {
    // Detect language
    const language = detectLanguage();
    console.log(`Detected language: ${language}`);
    
    // Find test files
    const testFiles = findTestFiles(language);
    console.log(`Found ${testFiles.length} test files`);
    
    if (testFiles.length === 0) {
      console.error('No test files found');
      process.exit(1);
    }
    
    // Run tests
    const results = runTests(language, testFiles);
    
    // Print summary
    console.log('\n--- Test Summary ---');
    console.log(`Total: ${results.passed + results.failed}`);
    console.log(`Passed: ${results.passed}`);
    console.log(`Failed: ${results.failed}`);
    
    // Save results to file
    fs.writeFileSync(
      path.join(workspaceDir, 'test-results.json'),
      JSON.stringify(results, null, 2)
    );
    
    // Also log the workspace directory for debugging
    console.log(`\nWorkspace directory: ${workspaceDir}`);
    console.log(`Project directory: ${projectDir}`);
    console.log(`Tests directory: ${testsDir}`);
    
    // Exit with appropriate code
    process.exit(results.failed > 0 ? 1 : 0);
  } catch (error) {
    console.error('Error running tests:', error);
    process.exit(1);
  }
}

// Run the main function
main();
