#!/bin/bash

# Start code-server in the background
code-server --bind-addr 0.0.0.0:8080 --auth password /workspace &

# Start the API server
node /workspace/test-runners/api-server.js
