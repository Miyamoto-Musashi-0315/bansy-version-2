# Code-Server Integration for Coding Assessment Platform

This directory contains the code-server integration for the AI-powered coding assessment platform. It provides a full VS Code experience in the browser for candidates taking coding tests.

## Overview

The code-server integration replaces the previous Replit approach, offering a more robust and customizable solution. It runs VS Code in the browser and executes code directly on Render.

## Components

1. **Dockerfile**: Configures a Docker image with code-server and multiple programming languages
2. **test-runners/**: Contains scripts for running tests in different languages
3. **api-server.js**: Simple API server to handle file operations and test execution

## Local Development

To run the code-server locally for development:

```bash
# Navigate to the code-server directory
cd code-server

# Create a workspace directory
mkdir -p workspace/project workspace/tests

# Build and run with Docker Compose
docker-compose up
```

Access the code-server at http://localhost:8080 with password "password".

## Deployment on Render

1. Push this code to your GitHub repository
2. Create a new Web Service on Render
3. Connect to your GitHub repository
4. Set the following:
   - Build Command: `docker-compose up -d`
   - Start Command: (leave empty)
5. Add environment variables:
   - `PASSWORD`: A secure password for code-server
   - `API_KEY`: A secure API key for the internal API server
   - `TEST_ID`: Will be set dynamically for each test

## Usage

The code-server integration works with the existing backend and frontend components:

- Frontend embeds the code-server instance in an iframe
- Backend creates and manages code-server instances on Render
- Test results are sent back to the main application

## Security

- Each candidate gets an isolated code-server instance
- Authentication is required to access the code-server
- API endpoints are protected with an API key
