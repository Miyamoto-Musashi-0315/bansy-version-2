const assert = require('assert');
const { arraySum } = require('../project/solution');

describe('Array Sum Challenge', () => {
  it('should return the sum of all elements in the array', () => {
    assert.strictEqual(arraySum([1, 2, 3, 4]), 10);
    assert.strictEqual(arraySum([5, 5, 5]), 15);
    assert.strictEqual(arraySum([10]), 10);
  });

  it('should return 0 for an empty array', () => {
    assert.strictEqual(arraySum([]), 0);
  });

  it('should handle negative numbers correctly', () => {
    assert.strictEqual(arraySum([-1, -2, -3]), -6);
    assert.strictEqual(arraySum([-1, 1]), 0);
    assert.strictEqual(arraySum([-5, 10]), 5);
  });
});
