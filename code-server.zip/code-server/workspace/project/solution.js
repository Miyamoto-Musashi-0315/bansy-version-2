/**
 * Array Sum Challenge
 * 
 * Write a function that takes an array of numbers and returns the sum of all elements.
 * If the array is empty, return 0.
 * 
 * Examples:
 * arraySum([1, 2, 3, 4]) => 10
 * arraySum([]) => 0
 * arraySum([-1, 1]) => 0
 */

function arraySum(numbers) {
  // Your solution here
}

module.exports = {
  arraySum
};
