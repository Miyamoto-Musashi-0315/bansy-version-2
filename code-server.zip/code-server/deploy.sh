#!/bin/bash

# Check if render-cli is installed
if ! command -v render &> /dev/null; then
    echo "render-cli is not installed. Installing..."
    npm install -g @render/cli
fi

# Check if RENDER_API_KEY is set
if [ -z "$RENDER_API_KEY" ]; then
    echo "RENDER_API_KEY is not set. Please set it in your environment variables."
    echo "You can get your API key from https://dashboard.render.com/account/api-keys"
    exit 1
fi

# Deploy to Render.com
echo "Deploying code-server to Render.com..."
render blueprint apply

echo "Deployment initiated. Check the status at https://dashboard.render.com"
echo "Once deployed, your code-server will be available at https://basny-version-1.onrender.com"
